class SLLNode { 
    constructor(val) {
        this.value = val 
        this.next = null 
    }
}

class SLL { 
    constructor() {  
        this.head = null  
    }

    addFront(value) {
        let newNode = new SLLNode(value)
        newNode.next = this.head
        this.head  = newNode
        return this.head; 
    }


    // Display the values of all the nodes in the list
    display() {
        let listStg = "" // Empty string that will contain the values of the list        
        // Edge case: list is empty
        if(this.head == null) {
            return "Empty list"
        }
        // We have at least one node
        listStg += this.head.value // Concatenates the first value in the list
        // For the second node onwards, we'll add ", " + value
        let runner = this.head.next 
        while (runner != null) {
            listStg += ", " + runner.value // Add the node's value to the list
            runner = runner.next // Move the runner to the next node
        }
        return listStg
    }
}

let mySLL = new SLL()

mySLL.addFront(205)
mySLL.addFront(87)
mySLL.addFront(25)

console.log(mySLL.display())