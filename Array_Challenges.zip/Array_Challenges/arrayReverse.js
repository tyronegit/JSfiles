function reverse(arr) {
    //Use of reverse method from JavaSCript methods
    arr.reverse()
    return arr
}

var result = reverse(["a", "b", "c", "d", "e"]);
console.log(result); // we expect back ["e", "d", "c", "b", "a"]
